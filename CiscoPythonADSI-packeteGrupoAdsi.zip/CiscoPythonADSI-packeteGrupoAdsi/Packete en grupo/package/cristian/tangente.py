def cosen_o():
    a1 = float(input("digite el primer angulo: "))
    a2 = float(input("digite el segundo angulo: "))
    cin = float(a1/a2)
    print("el coseno es",cin)
    
def tan_0():
    t1 = float(input("digite el primer angulo: "))
    t2 = float(input("digite el segundo angulo: "))
    tan = float(t1/t2)
    print("el tangente es",tan)
        
