#Python 3.9.5 (tags/v3.9.5:0a7dcbd, May  3 2021, 17:27:52) [MSC v.1928 64 bit (AMD64)] on win32
#Type "help", "copyright", "credits" or "license()" for more information.
def porcentaje ():
  a = int(input("Digite el Numero: "))
  b = int(input ("Digite el Procentaje: "))
  r = int((a*b)/100)
  print("El Porcentaje es ", r)



def sin():
  h = float(input("Digite la hiputenusa: "))
  a = float(input("Digite en angulo contrario a la hipotenusa: "))
  seno = float(a/h)
  print("El Seno de el triangulo rectangulo es", seno)