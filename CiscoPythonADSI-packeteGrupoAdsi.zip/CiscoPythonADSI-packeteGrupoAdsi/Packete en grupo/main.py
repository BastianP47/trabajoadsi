#!/usr/local/bin/python3.8

#Luis Fernando Ch. 2022
from menu import menu


if __name__ == "__main__":
    menu()




